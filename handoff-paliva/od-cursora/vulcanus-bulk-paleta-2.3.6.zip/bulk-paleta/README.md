# VULCANUS Bulk Paleta

WordPress modul **2.3.6**: shortcode `[vulcanus_paleta]` do Bricks / G3. Paleta je jednorazová, nevratná a v cene tovaru. Šírka = e-shop (1400 px).

- `[vulcanus_paleta]` — konfigurátor (`?palivo=uhlie|antracit|koks`)
- `[vulcanus_paleta_karty]` — tri karty od 100 kg v jazyku `vd-card`
- `/paliva/` na webe redirectuje do Woo

Vrecia s doručením nemente. Inštalácia: [`../handoff-paliva/od-cursora/HOTOVO.md`](../handoff-paliva/od-cursora/HOTOVO.md).
